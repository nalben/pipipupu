﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using diablo666.interfaces;
using System.Windows.Controls;
using diablo666.db_context;

namespace diablo666.logic
{
    public class Auth_logic : Auth_interface
    {
        demo_db_potorochinEntities db = new demo_db_potorochinEntities();
        public bool IsAuth(string login, string password)
        {
            var user = db.Staff.FirstOrDefault(u => u.User_password == password && u.FullName == login);
            if (user != null)
            {
                new Cleaner_window().Show();
                return true;
            }
            return false;
        }

    }
}
