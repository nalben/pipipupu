﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace diablo666.interfaces
{
    public interface Auth_interface
    {
        bool IsAuth(string login, string password);
    }
}
